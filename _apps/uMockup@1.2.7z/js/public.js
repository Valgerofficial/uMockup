$(document).ready(function() {
	// Запуск скриптов public.js
});
